# -*- coding: utf-8 -*-

"""Top-level package for Insta_Tweet."""

__author__ = """Sayak Sen"""
__email__ = 'sayak1997sen@gmail.com'
__version__ = '2.7'
