=======
History
=======

1.0 (2018-08-06)
------------------

* First release on PyPI.
