===========
Insta_Tweet
===========


.. image:: https://img.shields.io/pypi/v/insta_tweet.svg
        :target: https://pypi.python.org/pypi/insta_tweet

.. image:: https://img.shields.io/travis/sayak9495/insta_tweet.svg
        :target: https://travis-ci.org/sayak9495/insta_tweet

.. image:: https://readthedocs.org/projects/insta-tweet/badge/?version=latest
        :target: https://insta-tweet.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Scrapes specified Instagram accounts and tweets the pictures on Twitter.


* Free software: GNU General Public License v3
* Documentation: https://insta-tweet.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
