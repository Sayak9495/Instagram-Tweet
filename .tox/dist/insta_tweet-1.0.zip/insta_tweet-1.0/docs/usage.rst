=====
Usage
=====

To use Insta_Tweet in a project::

    import insta_tweet
